﻿using BankingApplication.DataAccess.DTO;
using BankingApplication.Services;
using BankingApplication.Services.Exceptions;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BankingApplication.Controllers
{
    public class AccountController : Controller
    {
        private readonly IOperations _service;

        public AccountController(IOperations service)
        {
            _service = service;
        }
        // GET: Account
        public async Task<ActionResult> IndexAsync()
        {   
            AccountActivity accountActivity = new AccountActivity();
            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Name); // will give the user's userName
                accountActivity = await _service.GetAccountActivityAsync(userName);
                return View(accountActivity);
            }
            catch (AccountException ex)
            {
                ModelState.AddModelError("NoAccounts", (ex.InnerException ?? ex).Message);              
                return View(accountActivity);
            }
            catch (PayeeException ex)
            {
                ModelState.AddModelError("NoPayees", (ex.InnerException ?? ex).Message);              
                return View(accountActivity);
            }
            catch (Exception)
            {
                throw;
            }
          
        }
              
    }
}
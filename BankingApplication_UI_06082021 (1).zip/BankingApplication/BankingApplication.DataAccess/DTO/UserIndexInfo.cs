﻿using BankingApplication.DataAccess.Models;

namespace BankingApplication.DataAccess.DTO
{
    public class UserIndexInfo
    {
        public string AccountNumber { get; set; }
        public UserPrimaryDetail userDetails { get; set; }
    }
}

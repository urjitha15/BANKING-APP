﻿using BankingApplication.DataAccess.DTO;
using BankingApplication.DataAccess.Models;
using BankingApplication.Services;
using BankingApplication.Services.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BankingApplication.Controllers
{
    [Authorize(Roles = "Customer")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IOperations _service;

        public HomeController(
            IOperations service,
            ILogger<HomeController> logger)
        {
            _service = service;
            _logger = logger;
        }

        public async Task<IActionResult> IndexAsync()
        {
            UserIndexInfo userDetails = new UserIndexInfo();
            try
            {
                // var AuthUserId = User.FindFirstValue(ClaimTypes.NameIdentifier); // will give the user's userId
                var userName = User.FindFirstValue(ClaimTypes.Name); // will give the user's userName
                userDetails = await _service.GetUserDetailsAsync(userName);
                return View(userDetails);
            }
            catch (AccountException ex)
            {
                ModelState.AddModelError("NoAccounts", (ex.InnerException ?? ex).Message);
                return View(userDetails);
            }
            catch (ResourceNotFoundException ex)
            {
                ErrorViewModel errorView = _service.GetMessageModel((ex.InnerException ?? ex).Message, false, "Login");
                return View("Error", errorView);
            }
            catch (Exception ex)
            {
                ErrorViewModel errorView = _service.GetMessageModel((ex.InnerException ?? ex).Message, false, "Login");
                return View("Error", errorView);
            }
        }



        public IActionResult Privacy()
        {
            return View();
        }

        [AllowAnonymous]        
        public IActionResult Error(ErrorViewModel errorViewModel)
        {
            return View(errorViewModel);
        }
    }
}

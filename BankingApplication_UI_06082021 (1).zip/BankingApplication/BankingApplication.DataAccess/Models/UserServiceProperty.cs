﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.DataAccess.Models
{
    public partial class UserServiceProperty
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public bool IsInternetBanking { get; set; }
        public bool IsMobileBanking { get; set; }
        public bool IsMessagesAllowed { get; set; }

        public virtual UserPrimaryDetail User { get; set; }
    }
}

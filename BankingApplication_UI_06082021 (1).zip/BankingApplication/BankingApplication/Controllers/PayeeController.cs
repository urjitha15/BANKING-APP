﻿using BankingApplication.DataAccess.Models;
using BankingApplication.Services;
using BankingApplication.Services.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BankingApplication.Controllers
{
    [Authorize(Roles = "Customer")]
    public class PayeeController : Controller
    {
        private readonly IOperations _service;

        public PayeeController(IOperations service)
        {
            _service = service;
        }

        // GET: Payee
        public async Task<ActionResult> Index()
        {
            List<UserPayeeMapping> objMasterPayees = new List<UserPayeeMapping>();
            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Name);
                objMasterPayees = await _service.GetUserPayeeDetailsAsync(userName);
                return View(objMasterPayees);

            }
            catch (PayeeException ex)
            {
                ModelState.AddModelError("NoPayees", (ex.InnerException ?? ex).Message);
                return View(objMasterPayees);
            }
        }

        public ActionResult AddPayee()
        {
            return View();
        }


        // POST: Payee/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AddPayeeAsync(MasterPayeeDetail payeeDetails)
        {
            var userName = User.FindFirstValue(ClaimTypes.Name);
            try
            {
                await _service.InsertPayeeDetails(userName, payeeDetails);
                return RedirectToAction(nameof(Index));
            }
            catch (AccountException ex)
            {
                ModelState.AddModelError("NoAccounts", (ex.InnerException ?? ex).Message);                
                return View(payeeDetails);
            }
            catch (Exception)
            {
                ModelState.AddModelError("FailedAddingPayee", "Unable to Add Payee. Please try again.");
                return View();
            }
        }

        // GET: Payee/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            var userName = User.FindFirstValue(ClaimTypes.Name);
            var userPayeeDetails = await _service.GetUserPayeeDetailsAsync(userName, id);
            return View(userPayeeDetails.FirstOrDefault());
        }

        // POST: Payee/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, UserPayeeMapping payeeDetails)
        {
            try
            {
                await _service.UpdatePayeeDetails(payeeDetails);
                return RedirectToAction(nameof(Index));
            }
            catch (ResourceNotFoundException ex)
            {
                ErrorViewModel errorView = _service.GetMessageModel((ex.InnerException ?? ex).Message, false, "Login");
                return View("Error", errorView);
            }
            catch (Exception ex)
            {
                ErrorViewModel errorView = _service.GetMessageModel((ex.InnerException ?? ex).Message, false, "Login");
                return View("Error", errorView);
            }
        }

        // GET: Payee/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            var userName = User.FindFirstValue(ClaimTypes.Name);
            var userPayeeDetails = await _service.GetUserPayeeDetailsAsync(userName, id);

            return View(userPayeeDetails.FirstOrDefault());
        }

        // POST: Payee/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            try
            {
                await _service.DeletePayeeDetails(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
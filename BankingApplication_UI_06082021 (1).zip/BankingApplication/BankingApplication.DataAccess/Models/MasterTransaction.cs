﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.DataAccess.Models
{
    public partial class MasterTransaction
    {
        public int Id { get; set; }
        public int? FromAccount { get; set; }
        public int TransactionType { get; set; }
        [Range(typeof(decimal), "1", "50000", ErrorMessage = "Allowed Amount per transaction is 1 to 50000")]
        public decimal Amount { get; set; }
        public int TransactionStatus { get; set; }
        public int? Payee { get; set; }
        public DateTime MadeOn { get; set; }


        public IEnumerable<UserAccountDetail> userAccounts { get; set; }
        public IEnumerable<UserPayeeMapping> payees { get; set; }

        public virtual UserAccountDetail FromAccountNavigation { get; set; }
    }
}

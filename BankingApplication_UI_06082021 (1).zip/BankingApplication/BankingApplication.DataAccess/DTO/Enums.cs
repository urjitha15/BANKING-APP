﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.DataAccess.DTO
{

    public enum AccountType
    {
        Savings = 1,
        Current = 2
    }

    public enum UserRole
    {
        Admin = 1,
        Customer = 2
    }

    public enum TransactionStatus
    {
        Intiated = 1,
        Successful = 2,
        Failed = 3,
        InProcess = 4
    }

    public enum TransactionType
    {
        Debit = 1,
        Credit = 2
    }

    public enum Operations
    {
        Deposit = 3,
        Withdrawal = 2,
        Transfer = 1,
    }

    public enum TransactionModes
    {
        NTFS = 1,
        RTGS = 2,
        IMPS = 3,
        UPI = 4,
        Check = 5
    }

    public enum BankType
    {
        [Display(Name = "Same Bank")]
        SameBank = 1,

        [Display(Name = "Other Bank")]
        DifferentBank = 2
    }

    public enum ModeOfTransaction
    {
        [Display(Name = "Digital")]
        FromAccount = 1,

        [Display(Name = "Cash")]
        ByCash = 2
    }




}

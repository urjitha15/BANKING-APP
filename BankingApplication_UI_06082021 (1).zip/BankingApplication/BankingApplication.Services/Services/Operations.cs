﻿using BankingApplication.DataAccess.DbContext;
using BankingApplication.DataAccess.DTO;
using BankingApplication.DataAccess.Models;
using BankingApplication.Services.Exceptions;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.Services
{
    public class ServiceOperations : IOperations
    {
        private readonly BankingDBContext _context;
        private readonly ICommonMethods _helper;
        private readonly UserManager<ApplicationUser> _userManager;

        public ServiceOperations(BankingDBContext context, UserManager<ApplicationUser> userManager, ICommonMethods helper)
        {
            _context = context;
            _helper = helper;
            _userManager = userManager;
        }



        /// <summary>
        /// Inserts Primary Details, Login Details, Account Details
        /// </summary>
        /// <param name="userDetails"></param>
        /// <returns></returns>
        public async Task<string> RegisterUserAsync(ApplicationUser userDetails)
        {
            var user = await InsertPrimaryDetails(userDetails);
            int userId = user.UserId;

            await InsertAuthPrimaryMapping(userDetails, userId);

            await InsertAccountDetails(userId);

            await InsertLogInTrack(userDetails.UserName, TransactionStatus.Successful);

            return string.Empty;
        }

        /// <summary>
        /// Insert Login Tracks
        /// </summary>
        /// <param name="userPrimaryDetail"></param>
        /// <returns></returns>
        public async Task InsertLogInTrack(string userName, TransactionStatus status)
        {
            var user = await _userManager.FindByNameAsync(userName);
            if (!await _userManager.IsInRoleAsync(user, UserRole.Customer.ToString()))
                return;

            int userId = await GetUserIdByAuthUserNameAsync(userName);
            _context.UserLoginTracks.Add(new UserLoginTrack
            {
                LoginDatetime = DateTime.Now,
                UserId = userId,
                Status = (int)status
            });
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Insert Payee Details Tracks
        /// </summary>
        /// <param name="userPrimaryDetail"></param>
        /// <returns></returns>
        public async Task<int> InsertPayeeDetails(string userName, MasterPayeeDetail payeeDetails)
        {
            string userId = await GetUserIdFromAuthUserNameAsync(userName);
            payeeDetails.IsSameBank = payeeDetails.BankType == BankType.SameBank ? true : false;
            if (payeeDetails.IsSameBank)
            {
                CheckAccountAvailability(payeeDetails.AccountNumber);

            }
            var addedPayee = await AddPayeeAccount(payeeDetails);
            _context.UserPayeeMappings.Add(
                new UserPayeeMapping
                {
                    IsActive = true,
                    IsDeleted = false,
                    PayeeId = addedPayee.Id,
                    Username = userId
                });
            await _context.SaveChangesAsync();
            return addedPayee.Id;
        }

        /// <summary>
        /// Initiate Transferring Funds
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="transferDetails"></param>
        /// <returns></returns>
        public async Task<MasterTransaction> InitiateTransfers(MasterTransaction transferDetails)
        {
            try
            {
                CheckAvailbleFund(transferDetails);
                transferDetails.TransactionType = (int)TransactionType.Debit;
                transferDetails.TransactionStatus = (int)TransactionStatus.Intiated;
                transferDetails.MadeOn = DateTime.Now;
                return await InsertTransaction(transferDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Confirm Transferring Funds
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="transferDetails"></param>
        /// <returns></returns>
        public async Task<ErrorViewModel> ConfirmTransfers(ConfirmTransfer confirmation)
        {
            ErrorViewModel status;
            try
            {
                //MasterTransaction objTransaction = _context.MasterTransactions.FirstOrDefault(x => x.Id == confirmationId);
                //objTransaction.TransactionStatus = (int)TransactionStatus.InProcess;
                //CheckAvailbleFund(objTransaction);
                //await UpdateAccountBalanceAsync(objTransaction, TransactionType.Debit);
                //_context.MasterTransactions.Update(objTransaction);
                //await _context.SaveChangesAsync();

                //status = GetMessageModel("Fund Transfer Succesful, Will take 5 Minutes to Get reflect in your Account", true);
                //return status;
                confirmation.TransactionOperation = Operations.Transfer;
                confirmation.ToAccountNumber = confirmation.payeeDetails.AccountNumber;
                status = await ConfirmTransfersByAdmin(confirmation);
            }
            catch (Exception ex)
            {
                status = GetMessageModel((ex.InnerException ?? ex).Message, false);
            }
            return status;
        }

        /// <summary>
        /// Confirm Transferring Funds
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="transferDetails"></param>
        /// <returns></returns>
        public async Task<ErrorViewModel> ConfirmTransfersByAdmin(ConfirmTransfer transfer)
        {
            ErrorViewModel status;
            MasterTransaction objTransaction = _context.MasterTransactions.FirstOrDefault(x => x.Id == transfer.Id);
            objTransaction.TransactionStatus = (int)TransactionStatus.InProcess;
            try
            {
                switch (transfer.TransactionOperation)
                {
                    case Operations.Deposit:
                        objTransaction.FromAccount = _context.UserAccountDetails.FirstOrDefault(x => x.AccountNumber == transfer.ToAccountNumber).Id;
                        await UpdateAccountBalanceAsync(objTransaction, TransactionType.Credit);
                        break;
                    case Operations.Withdrawal:
                        CheckAvailbleFund(objTransaction);
                        await UpdateAccountBalanceAsync(objTransaction, TransactionType.Debit);
                        break;
                    case Operations.Transfer:
                        //if (transfer.ModeOfTransaction == ModeOfTransaction.FromAccount)
                        //{
                        CheckAvailbleFund(objTransaction);
                        await UpdateAccountBalanceAsync(objTransaction, TransactionType.Debit);
                        await UpdateTransactions(objTransaction);
                        //}
                        if (transfer.payeeDetails.BankType == BankType.SameBank)
                        {
                            var ToAccountNumber = _context.UserAccountDetails.FirstOrDefault(x => x.AccountNumber == transfer.ToAccountNumber).Id;

                            await UpdateAccountBalanceAsync(new MasterTransaction { Amount = objTransaction.Amount, FromAccount = ToAccountNumber }, TransactionType.Credit);

                            _context.MasterTransactions.Add(new MasterTransaction
                            {
                                Amount = objTransaction.Amount,
                                FromAccount = ToAccountNumber,
                                MadeOn = DateTime.Now,
                                TransactionStatus = (int)TransactionStatus.Successful,
                                TransactionType = (int)TransactionType.Credit,
                                Payee = objTransaction.FromAccount
                            });
                            await _context.SaveChangesAsync();
                        }
                        break;
                }

                status = GetMessageModel("Fund Transfer Succesful, Will take 5 Minutes to Get reflect in your Account", true);
                return status;
            }
            catch (Exception ex)
            {
                status = GetMessageModel((ex.InnerException ?? ex).Message, false);
            }
            return status;
        }

        /// <summary>
        /// Inserts the Payee Details to Payee Account
        /// </summary>
        /// <param name="payeeDetails"></param>
        /// <returns></returns>
        private async Task<MasterPayeeDetail> AddPayeeAccount(MasterPayeeDetail payeeDetails)
        {
            var addedPayee = _context.MasterPayeeDetails.Add(new MasterPayeeDetail
            {
                AccountHolderName = payeeDetails.AccountHolderName,
                AccountNumber = payeeDetails.AccountNumber,
                BankName = payeeDetails.BankName,
                Ifsc = payeeDetails.Ifsc,
                TransacationMode = (int)payeeDetails.TransacationModeNames,
                Upa = payeeDetails.Upa,
                IsSameBank = payeeDetails.IsSameBank
            });
            await _context.SaveChangesAsync();
            return addedPayee.Entity;
        }

        /// <summary>
        /// Inserts Primaty details
        /// </summary>
        /// <param name="userPrimaryDetail"></param>
        /// <returns></returns>
        private async Task<UserPrimaryDetail> InsertPrimaryDetails(ApplicationUser userDetail)
        {
            var userPrimaryDetails = new UserPrimaryDetail
            {
                Address = userDetail.Address,
                FirstName = _helper.FirstCharToUpper(userDetail.FirstName),
                IsActive = true,
                LastName = _helper.FirstCharToUpper(userDetail.LastName),
                CreatedOn = DateTime.Now,
            };

            _context.UserPrimaryDetails.Add(userPrimaryDetails);
            await _context.SaveChangesAsync();
            return userPrimaryDetails;
        }

        /// <summary>
        /// Inserts the Auth Primary Details Mapping
        /// </summary>
        /// <param name="userDetails"></param>
        /// <returns></returns>
        private async Task InsertAuthPrimaryMapping(ApplicationUser userDetails, int userId)
        {
            var userPrimaryDetails = new AuthUserMapping
            {
                AuthUserId = userDetails.Id,
                UserId = userId,
                Username = userDetails.UserName
            };

            _context.AuthUserMappings.Add(userPrimaryDetails);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Insert Account Details
        /// </summary>
        /// <param name="userPrimaryDetail"></param>
        /// <returns></returns>
        private async Task InsertAccountDetails(int userId)
        {
            var accountDetail = new UserAccountDetail
            {
                AccountNumber = _helper.GenerateRandomAccountNumber(),
                AccountType = (int)AccountType.Savings,
                CurrentBalance = 500,
                IsActive = true,
                UserId = userId,
            };
            _context.UserAccountDetails.Add(accountDetail);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Inserts into Transactions
        /// </summary>
        /// <param name="transactionDetails"></param>
        /// <returns></returns>
        private async Task<MasterTransaction> InsertTransaction(MasterTransaction transactionDetails)
        {
            try
            {
                var transactionDetail = _context.MasterTransactions.Add(transactionDetails);
                await _context.SaveChangesAsync();
                return transactionDetail.Entity;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<ConfirmTransfer> InitiateTransferByAdmin(string userName, ConfirmTransfer transfer)
        {
            MasterTransaction masterTransaction = new MasterTransaction
            {
                Amount = transfer.amount
            };
            masterTransaction.FromAccount = null;
            masterTransaction.Payee = null;
            masterTransaction.TransactionStatus = (int)TransactionStatus.Intiated;

            await ValidateTransactionAsync(userName, transfer, masterTransaction);
            transfer.payeeDetails.AccountHolderName = transfer.payeeDetails.AccountHolderName;
            masterTransaction.TransactionStatus = (int)TransactionStatus.Intiated;
            masterTransaction.MadeOn = DateTime.Now;
            var initiateTransaction = await InsertTransaction(masterTransaction);
            transfer.Id = initiateTransaction.Id;
            return transfer;
        }

        /// <summary>
        /// Validates the Transacation
        /// </summary>
        /// <param name="transfer"></param>
        /// <param name="masterTransaction"></param>
        /// <returns></returns>
        private async Task ValidateTransactionAsync(string userName, ConfirmTransfer transfer, MasterTransaction masterTransaction)
        {
            switch (transfer.TransactionOperation)
            {
                case Operations.Deposit:
                    transfer.accountDetails = new UserAccountDetail
                    {
                        Id = CheckAccountAvailability(transfer.ToAccountNumber),
                        AccountNumber = transfer.ToAccountNumber
                    };
                    masterTransaction.TransactionType = (int)TransactionType.Credit;
                    masterTransaction.FromAccount = transfer.accountDetails.Id;
                    break;
                case Operations.Withdrawal:
                    transfer.accountDetails.Id = CheckAccountAvailability(transfer.accountDetails.AccountNumber);
                    masterTransaction.TransactionType = (int)TransactionType.Debit;
                    masterTransaction.FromAccount = transfer.accountDetails.Id;
                    CheckAvailbleFund(masterTransaction);
                    break;
                case Operations.Transfer:
                    //if (transfer.ModeOfTransaction == ModeOfTransaction.FromAccount)
                    //{
                    transfer.accountDetails.Id = CheckAccountAvailability(transfer.accountDetails.AccountNumber);
                    masterTransaction.FromAccount = transfer.accountDetails.Id;
                    CheckAvailbleFund(masterTransaction);
                    masterTransaction.TransactionType = (int)TransactionType.Debit;
                    //} 
                    if (transfer.payeeDetails.BankType == BankType.SameBank)
                    {
                        transfer.accountDetails.Id = CheckAccountAvailability(transfer.ToAccountNumber);
                        var toAccountUserId = _context.UserAccountDetails.FirstOrDefault(x => x.Id == transfer.accountDetails.Id).UserId;
                        var toAccountDetails = _context.UserPrimaryDetails.FirstOrDefault(x => x.UserId == toAccountUserId);
                        transfer.payeeDetails = new MasterPayeeDetail
                        {
                            AccountHolderName = string.Join(' ', toAccountDetails.FirstName, toAccountDetails.LastName),
                            AccountNumber = transfer.ToAccountNumber,
                            BankType = BankType.SameBank
                        };
                    }
                    else
                    {
                        masterTransaction.Payee = await InsertPayeeDetails(userName, new MasterPayeeDetail
                        {
                            AccountHolderName = transfer.payeeDetails.AccountHolderName,
                            AccountNumber = transfer.ToAccountNumber,
                            BankName = transfer.payeeDetails.BankName,
                            Ifsc = transfer.payeeDetails.Ifsc,
                            TransacationMode = (int)TransactionModes.NTFS,
                            Upa = transfer.payeeDetails.Upa,
                            IsSameBank = false
                        });
                    }

                    break;
            }
        }


        /// <summary>
        /// Gets the User Details
        /// </summary>
        /// <returns></returns>
        public async Task<UserIndexInfo> GetUserDetailsAsync(string userName, string accountNumber = "")
        {
            var user = await _userManager.FindByNameAsync(userName);
            int userId = 0;

            if (await _userManager.IsInRoleAsync(user, UserRole.Admin.ToString()))
            {
                userId = GetUserIdByAccountNumber(accountNumber);
            }
            if (await _userManager.IsInRoleAsync(user, UserRole.Customer.ToString()))
            {
                userId = await GetUserIdByAuthUserNameAsync(userName);
            }

            UserPrimaryDetail userDetails = GetUserPrimaryDetails(userId);
            userDetails.UserLoginTracks = userDetails.UserLoginTracks.OrderByDescending(x => x.Id).Skip(1).Take(1).ToList();
            userDetails.UserAccountDetails = GetAccounts(userId);

            UserIndexInfo userInfo = new UserIndexInfo
            {
                userDetails = userDetails
            };

            return userInfo;
        }

        /// <summary>
        /// Get the user Id by the Account Number
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        private int GetUserIdByAccountNumber(string accountNumber)
        {
            var userId = _context.UserAccountDetails.FirstOrDefault(x => x.AccountNumber == accountNumber)?.UserId;
            if (userId == null)
            {
                throw new AccountException("Account Number Doesn't Exist");
            }
            return userId.Value;
        }

        /// <summary>
        /// Gives the User Primary Details
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private UserPrimaryDetail GetUserPrimaryDetails(int userId)
        {
            var userDetails = _context.UserPrimaryDetails.Include(x => x.UserLoginTracks)
                .FirstOrDefault(x => x.UserId == userId && x.IsActive == true);
            if (userDetails == null)
            {
                throw new ResourceNotFoundException("User Account is locked or Inactive");
            }

            return userDetails;
        }

        /// <summary>
        /// Get Active Account Details
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private List<UserAccountDetail> GetAccounts(int userId, bool IsTransaction = false)
        {
            var UserAccountDetails = _context.UserAccountDetails.Where(x => x.UserId == userId
                                      && x.IsActive == (IsTransaction ? x.IsActive : true)).ToList();
            if (UserAccountDetails.Count == 0)
            {
                throw new AccountException("No Active Accounts Found");
            }
            return UserAccountDetails;
        }

        /// <summary>
        /// Gets the User Details
        /// </summary>
        /// <returns></returns>
        public async Task<List<UserPayeeMapping>> GetUserPayeeDetailsAsync(string userName, int? Id = null, bool IsToTransferIndex = false)
        {
            var userId = await GetUserIdFromAuthUserNameAsync(userName);
            var userPayeeAccounts = _context.UserPayeeMappings.Include(x => x.Payee).Where(x => x.Username == userId
                                     && x.IsActive == (IsToTransferIndex ? IsToTransferIndex : x.IsActive)
                                     && x.IsDeleted == false
                                     && x.Id == (Id ?? x.Id)).ToList();

            if (userPayeeAccounts.Count == 0)
            {
                throw new PayeeException("No Payee Details Found");
            }
            foreach (var item in userPayeeAccounts)
            {
                item.Payee.TransacationModeNames = (TransactionModes)item.Payee.TransacationMode;
                item.Payee.BankType = item.Payee.IsSameBank ? BankType.SameBank : BankType.DifferentBank;
            }
            return userPayeeAccounts;
        }

        /// <summary>
        /// Gets the Master Transaction Details
        /// </summary>
        /// <returns></returns>
        public async Task<MasterTransaction> GetUserTransactionIndexDetailsAsync(string userName)
        {
            var userId = await GetUserIdByAuthUserNameAsync(userName);

            MasterTransaction objMasterTransaction = new MasterTransaction()
            {
                userAccounts = GetAccounts(userId),
                payees = await GetUserPayeeDetailsAsync(userName, null, true)
            };
            return objMasterTransaction;
        }

        /// <summary>
        /// Get Message Model
        /// </summary>
        /// <param name="_message"></param>
        /// <param name="_type"></param>
        /// <param name="_requestId"></param>
        /// <returns></returns>
        public ErrorViewModel GetMessageModel(string _message, bool _type, string _requestId = "")
        {
            return new ErrorViewModel
            {
                Message = _message,
                Type = _type,
                RequestId = _requestId
            };
        }

        /// <summary>
        /// Gets the Confirm Transfer Details
        /// </summary>
        /// <returns></returns>
        public ConfirmTransfer GetFundTransferConfirmationsAync(MasterTransaction initiatedTransfer)
        {
            ConfirmTransfer confirmTransfer = new ConfirmTransfer
            {
                Id = initiatedTransfer.Id,
                accountDetails = _context.UserAccountDetails.FirstOrDefault(x => x.Id == initiatedTransfer.FromAccount),
                amount = initiatedTransfer.Amount,
                payeeDetails = _context.MasterPayeeDetails.FirstOrDefault(x => x.Id == initiatedTransfer.Payee)
            };

            confirmTransfer.payeeDetails.TransacationModeNames = (TransactionModes)confirmTransfer.payeeDetails.TransacationMode;
            confirmTransfer.payeeDetails.BankType = confirmTransfer.payeeDetails.IsSameBank ? BankType.SameBank : BankType.DifferentBank;
            confirmTransfer.payeeDetails.BankName = confirmTransfer.payeeDetails.BankName ?? BankType.SameBank.ToString();
            confirmTransfer.payeeDetails.Ifsc = confirmTransfer.payeeDetails.Ifsc ?? "NA";
            confirmTransfer.payeeDetails.Upa = confirmTransfer.payeeDetails.Upa ?? "NA";

            return confirmTransfer;
        }


        /// <summary>
        /// Gets the Confirm Transfer Details
        /// </summary>
        /// <returns></returns>
        public ConfirmTransfer GetFundTransferConfirmationsAdminAync(ConfirmTransfer initiatedTransfer)
        {

            var transactionDetails = _context.MasterTransactions.FirstOrDefault(x => x.Id == initiatedTransfer.Id);
            initiatedTransfer.accountDetails = _context.UserAccountDetails.FirstOrDefault(x => x.Id == transactionDetails.FromAccount);
            if (initiatedTransfer.TransactionOperation == Operations.Withdrawal)
            {
                initiatedTransfer.ToAccountNumber = initiatedTransfer.accountDetails.AccountNumber;
            }                      
            if (transactionDetails.Payee != null)
            {
                initiatedTransfer.payeeDetails = _context.MasterPayeeDetails.FirstOrDefault(x => x.Id == transactionDetails.Payee);
            }
            else
            {
                var userId = _context.UserAccountDetails.FirstOrDefault(x => x.AccountNumber == initiatedTransfer.ToAccountNumber).UserId;
                var userDetails = _context.UserPrimaryDetails.FirstOrDefault(x => x.UserId == userId);
                initiatedTransfer.payeeDetails = new MasterPayeeDetail
                {
                    AccountHolderName = string.Join(' ', userDetails.FirstName, userDetails.LastName),
                    AccountNumber = initiatedTransfer.ToAccountNumber,
                    BankName = BankType.SameBank.ToString(),
                    TransacationModeNames = TransactionModes.NTFS,
                    IsSameBank = true,
                    BankType = BankType.SameBank
                };
            }
            if (initiatedTransfer.TransactionOperation == Operations.Deposit)
            {             
                initiatedTransfer.ModeOfTransaction = ModeOfTransaction.ByCash;
                initiatedTransfer.payeeDetails.BankType = BankType.SameBank;
                var userPrimaryDetail = _context.UserAccountDetails.Include(x => x.User)
                    .FirstOrDefault(x => x.AccountNumber == initiatedTransfer.ToAccountNumber).User;
                initiatedTransfer.payeeDetails = new MasterPayeeDetail
                {
                    AccountHolderName = string.Join(' ', userPrimaryDetail.FirstName, userPrimaryDetail.LastName),
                    AccountNumber = initiatedTransfer.ToAccountNumber
                };
            }

            return initiatedTransfer;
        }

        public async Task<AccountActivity> GetAccountActivityAsync(string userName)
        {
            var userId = await GetUserIdByAuthUserNameAsync(userName);
            var userAccounts = GetAccounts(userId, true);


            List<MasterTransaction> transactionsOfAllAccounts = new List<MasterTransaction>();
            foreach (var item in userAccounts)
            {
                var transactions = _context.MasterTransactions.Where(x => x.FromAccount == item.Id).ToList();
                transactionsOfAllAccounts.AddRange(transactions);
            }

            List<UserLoginTrack> loginTracks = _context.UserLoginTracks.Where(x => x.UserId == userId).OrderByDescending(x => x.Id).Take(5).ToList();
            List<TransactionDetails> transactionDetails = await GetTransactionDetailsOfAllAccountsAsync(transactionsOfAllAccounts);

            AccountActivity accountActivity = new AccountActivity
            {
                loginTrack = loginTracks,
                transactionDetails = transactionDetails
            };

            return accountActivity;
        }

        private async Task<List<TransactionDetails>> GetTransactionDetailsOfAllAccountsAsync(List<MasterTransaction> transactionsOfAllAccounts)
        {
            await UpdateInProcessTransactionStatusAsync(transactionsOfAllAccounts);
            List<TransactionDetails> transactionDetails = new List<TransactionDetails>();
            foreach (var transaction in transactionsOfAllAccounts)
            {
                var payeeDetails = _context.MasterPayeeDetails.FirstOrDefault(x => x.Id == transaction.Payee);
                var accountDetails = _context.UserAccountDetails.FirstOrDefault(x => x.Id == transaction.FromAccount);
                transactionDetails.Add(new TransactionDetails
                {
                    Id = transaction.Id,
                    FromAccount = accountDetails.AccountNumber,
                    MadeOn = transaction.MadeOn,
                    To = payeeDetails?.AccountHolderName ?? "Admin",
                    transactionStatus = (TransactionStatus)transaction.TransactionStatus,
                    transactionType = (TransactionType)transaction.TransactionType,
                    Amount = transaction.Amount
                });
            }
            if (transactionDetails.Count == 0)
            {
                throw new AccountException("No Transactions Found");
            }
            return transactionDetails.OrderByDescending(x => x.Id).ToList();
        }

        private async Task UpdateInProcessTransactionStatusAsync(List<MasterTransaction> transactionsOfAllAccounts)
        {
            var completed = transactionsOfAllAccounts.Where(x => x.TransactionStatus == (int)TransactionStatus.InProcess && x.MadeOn.AddMinutes(5).Ticks <= DateTime.Now.Ticks);
            foreach (var item in completed)
            {
                item.TransactionStatus = (int)TransactionStatus.Successful;
                _context.Update(item);
            }

            await _context.SaveChangesAsync();
        }

        private async Task UpdateTransactions(MasterTransaction transaction)
        {
            var transactionDetails = _context.MasterTransactions.FirstOrDefault(x => x.Id == transaction.Id);
            transactionDetails.TransactionStatus = transaction.TransactionStatus;
            _context.MasterTransactions.Update(transactionDetails);
            await _context.SaveChangesAsync();
        }


        /// <summary>
        /// Update Payee Details
        /// </summary>
        /// <param name="userPrimaryDetail"></param>
        /// <returns></returns>
        public async Task UpdatePayeeDetails(UserPayeeMapping payeeDetails)
        {
            payeeDetails.Payee.TransacationMode = (int)payeeDetails.Payee.TransacationModeNames;
            _context.Update(payeeDetails);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Update Account Balance into Account Details
        /// </summary>
        /// <param name="transactionDetails"></param>
        /// <returns></returns>
        private async Task UpdateAccountBalanceAsync(MasterTransaction transactionDetails, TransactionType transactionType)
        {
            try
            {
                var accountDetails = _context.UserAccountDetails.FirstOrDefault(x => x.Id == transactionDetails.FromAccount);
                switch (transactionType)
                {
                    case TransactionType.Debit:
                        accountDetails.CurrentBalance -= transactionDetails.Amount;
                        break;

                    case TransactionType.Credit:
                        accountDetails.CurrentBalance += transactionDetails.Amount;

                        break;
                }
                _context.UserAccountDetails.Update(accountDetails);
                await _context.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
        


        /// <summary>
        /// Delete Payee Details
        /// </summary>
        /// <param name="userPrimaryDetail"></param>
        /// <returns></returns>
        public async Task DeletePayeeDetails(int Id)
        {
            var payeeDetails = _context.UserPayeeMappings.FirstOrDefault(x => x.Id == Id);
            payeeDetails.IsDeleted = true;
            _context.UserPayeeMappings.Update(payeeDetails);
            await _context.SaveChangesAsync();
        }


        /// <summary>
        /// Inserts the Payee Details to Payee Account
        /// </summary>
        /// <param name="payeeDetails"></param>
        /// <returns></returns>
        private void CheckAvailbleFund(MasterTransaction transactionDetails)
        {
            var IsFundAvailable = _context.UserAccountDetails.FirstOrDefault(x => x.Id == transactionDetails.FromAccount
                                      && x.CurrentBalance >= transactionDetails.Amount && x.IsActive == true);
            if (IsFundAvailable == null)
            {
                throw new InSufficientFund("Selected Account has InSufficient fund");
            }
            //return IsFundAvailable;
        }

        /// <summary>
        /// Check User Account exists or Not
        /// </summary>
        /// <param name="payeeDetails"></param>
        /// <returns></returns>
        private int CheckAccountAvailability(string accountNumber)
        {
            var IsAccountAvailable = _context.UserAccountDetails.FirstOrDefault(x => x.AccountNumber == accountNumber);
            if (IsAccountAvailable == null)
            {
                throw new AccountException($"Account Number {accountNumber} Doesn't Exist");
            }
            if (IsAccountAvailable.IsActive != true)
            {
                throw new AccountException("Account is Inactive");
            }

            return IsAccountAvailable.Id;
        }

        /// <summary>
        /// Gets the User Id from Auth Mapping Table by the username
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        private async Task<int> GetUserIdByAuthUserNameAsync(string userName)
        {
            var AuthUser = await _userManager.FindByNameAsync(userName); // will give the user's userId

            var userId = _context.AuthUserMappings.FirstOrDefault(x => x.AuthUserId == AuthUser.Id).UserId;
            return userId;
        }

        /// <summary>
        /// Gets the User Id from Net user Table
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        private async Task<string> GetUserIdFromAuthUserNameAsync(string userName)
        {
            var AuthUser = await _userManager.FindByNameAsync(userName); // will give the user's userId
            return AuthUser.Id;
        }
    }
}

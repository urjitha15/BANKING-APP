﻿using BankingApplication.DataAccess.DTO;
using BankingApplication.DataAccess.Models;
using BankingApplication.Services;
using BankingApplication.Services.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BankingApplication.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {

        private readonly ILogger<AdminController> _logger;
        private readonly IOperations _service;

        public AdminController(
            IOperations service,
            ILogger<AdminController> logger)
        {
            _service = service;
            _logger = logger;
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult FundTransfer()
        {
            return View();
        }

        // GET: Admin/Create
        public ActionResult CustomerInformation()
        {
            return View(null);
        }

        // POST: Admin/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CustomerInformationAsync(UserIndexInfo adminUserInfo)
        {
            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Name); // will give the user's userName
                adminUserInfo = await _service.GetUserDetailsAsync(userName, adminUserInfo.AccountNumber);
                return View(nameof(CustomerInformation),adminUserInfo);
            }
            catch (AccountException ex)
            {
                ModelState.AddModelError("NoAccounts", (ex.InnerException ?? ex).Message);
                return View(null);
            }
            catch
            {
                return View();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<ActionResult> FundTransferAsync(ConfirmTransfer transfer)
        {
            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Name); // will give the user's userName
                transfer = await _service.InitiateTransferByAdmin(userName, transfer);
                return RedirectToAction("Confirm", transfer);
            }
            catch (AccountException ex)
            {
                ModelState.AddModelError("NoAccounts", (ex.InnerException ?? ex).Message);
                return View(transfer);
            }
            catch (InSufficientFund ex)
            {
                ModelState.AddModelError("InSufficientFund", (ex.InnerException ?? ex).Message);
                return View(transfer);
            }
            catch(Exception ex)
            {
                ModelState.AddModelError("Exception", (ex.InnerException ?? ex).Message);
                return View(transfer);
            }
        }



        public ActionResult Confirm(ConfirmTransfer transferDetails)
        {
            
            var confirmedDetails = _service.GetFundTransferConfirmationsAdminAync(transferDetails);
            return View(confirmedDetails);
        }

        // POST: Transfer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ConfirmAsync(ConfirmTransfer transferDetails)
        {
            ErrorViewModel errorViewModel = await _service.ConfirmTransfersByAdmin(transferDetails);
            return View("Error", errorViewModel);
        }


    }
}
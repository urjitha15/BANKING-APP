﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.DataAccess.Models
{
    public partial class UserPrimaryDetail
    {
        public UserPrimaryDetail()
        {
            UserAccountDetails = new HashSet<UserAccountDetail>();
            UserLoginTracks = new HashSet<UserLoginTrack>();
            UserPayeeMappings = new HashSet<UserPayeeMapping>();
            UserServiceProperties = new HashSet<UserServiceProperty>();
        }

        [Key]
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Gender { get; set; }
        public string Address { get; set; }
        public string Ssn { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }

        public virtual ICollection<UserAccountDetail> UserAccountDetails { get; set; }
        public virtual ICollection<UserLoginTrack> UserLoginTracks { get; set; }
        public virtual ICollection<UserPayeeMapping> UserPayeeMappings { get; set; }
        public virtual ICollection<UserServiceProperty> UserServiceProperties { get; set; }
    }
}

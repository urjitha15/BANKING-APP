﻿using BankingApplication.DataAccess.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace BankingApplication.DataAccess.DTO
{
    public class ConfirmTransfer
    {
        public int Id { get; set; }
        public MasterPayeeDetail payeeDetails { get; set; }
        public UserAccountDetail accountDetails { get; set; }

        [Required]
        [Range(typeof(decimal), "1", "50000", ErrorMessage = "Allowed Amount per transaction is 1 to 50000")]
        public decimal amount { get; set; }

        [Required]
        public Operations TransactionOperation { get; set; }

        //[Required]
        //public BankType BankType { get; set; }

        [Required]
        public ModeOfTransaction ModeOfTransaction { get; set; }

        [StringLength(15, ErrorMessage = "Maximum allowed account Number length is 15")]
        public string ToAccountNumber { get; set; }


    }
}

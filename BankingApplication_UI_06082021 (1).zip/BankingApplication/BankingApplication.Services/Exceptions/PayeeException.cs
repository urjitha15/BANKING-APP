﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.Services.Exceptions
{
    [Serializable]
    public class PayeeException : Exception
    {
        public PayeeException()
        {

        }

        public PayeeException(string message) : base(message)
        {

        }
    }
}

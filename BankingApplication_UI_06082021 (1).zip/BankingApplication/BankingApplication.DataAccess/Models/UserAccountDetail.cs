﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.DataAccess.Models
{  

    public partial class UserAccountDetail
    {
        public UserAccountDetail()
        {
            MasterTransactions = new HashSet<MasterTransaction>();
        }

        public int Id { get; set; }
        public int UserId { get; set; }

        [StringLength(15, ErrorMessage = "Maximum allowed account Number length is 15")]
        public string AccountNumber { get; set; }
        public int AccountType { get; set; }
        public decimal CurrentBalance { get; set; }
        public bool IsActive { get; set; }



        public virtual UserPrimaryDetail User { get; set; }
        public virtual ICollection<MasterTransaction> MasterTransactions { get; set; }
    }
}

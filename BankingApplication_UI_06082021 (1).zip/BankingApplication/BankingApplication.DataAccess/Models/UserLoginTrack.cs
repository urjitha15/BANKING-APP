﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.DataAccess.Models
{
    public partial class UserLoginTrack
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public DateTime LoginDatetime { get; set; }
        public int Status { get; set; }

        public virtual UserPrimaryDetail User { get; set; }
    }
}

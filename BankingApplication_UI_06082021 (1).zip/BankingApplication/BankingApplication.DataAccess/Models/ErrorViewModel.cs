using System;

namespace BankingApplication.DataAccess.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }
        public bool Type { get; set; }
        public string Message { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

    }
}

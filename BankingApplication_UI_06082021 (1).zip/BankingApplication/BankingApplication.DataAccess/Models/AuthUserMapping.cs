﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.DataAccess.Models
{
    public partial class AuthUserMapping
    {
        public int Id { get; set; }
        public string AuthUserId { get; set; }
        public string Username { get; set; }
        public int UserId { get; set; }
    }
}

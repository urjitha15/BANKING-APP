﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.Services.Exceptions
{    
    [Serializable]
    public class InSufficientFund : Exception
    {
        public InSufficientFund()
        {

        }

        public InSufficientFund(string message) : base(message)
        {

        }
    }
}

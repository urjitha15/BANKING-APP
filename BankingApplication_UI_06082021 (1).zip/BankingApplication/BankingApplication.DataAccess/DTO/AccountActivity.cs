﻿using BankingApplication.DataAccess.Models;
using System;
using System.Collections.Generic;

namespace BankingApplication.DataAccess.DTO
{
    public class AccountActivity
    {
        public AccountActivity()
        {
            loginTrack = new List<UserLoginTrack>();
            transactionDetails = new List<TransactionDetails>();
        }

        public List<TransactionDetails> transactionDetails { get; set; }

        public List<UserLoginTrack> loginTrack { get; set; }
    }

    public class TransactionDetails
    {
        public int Id { get; set; }
        public string FromAccount { get; set; }
        public string To { get; set; }
        public DateTime MadeOn { get; set; }
        public TransactionType transactionType { get; set; }
        public TransactionStatus transactionStatus { get; set; }
        public decimal Amount { get; set; }
    }

}

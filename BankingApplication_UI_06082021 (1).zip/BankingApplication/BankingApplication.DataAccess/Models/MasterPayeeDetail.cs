﻿using BankingApplication.DataAccess.DTO;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BankingApplication.DataAccess.Models
{
    public partial class MasterPayeeDetail
    {
        public MasterPayeeDetail()
        {
            UserPayeeMappings = new HashSet<UserPayeeMapping>();
        }

        [Required]
        public int Id { get; set; }

        [Required]
        public int TransacationMode { get; set; }
               
        public string BankName { get; set; }
               
        public string Ifsc { get; set; }
              
        public string AccountHolderName { get; set; }
               
        public string AccountNumber { get; set; }
               
        public string Upa { get; set; }
        public bool IsSameBank { get; set; }

        [Required]
        public TransactionModes TransacationModeNames { get; set; }

        [Required]
        public BankType BankType { get; set; }

        public virtual ICollection<UserPayeeMapping> UserPayeeMappings { get; set; }
    }
}

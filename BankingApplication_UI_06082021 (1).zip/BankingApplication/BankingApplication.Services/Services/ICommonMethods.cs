﻿namespace BankingApplication.Services
{
    public interface ICommonMethods
    {
        string GenerateRandomAccountNumber();
        string RandomUserName();

        string Base64Encode(string plainText);
        string Base64Decode(string base64EncodedData);
        string FirstCharToUpper(string input);
    }
}

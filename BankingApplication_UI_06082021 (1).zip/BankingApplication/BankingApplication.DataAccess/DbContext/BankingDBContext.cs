﻿using BankingApplication.DataAccess.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;

namespace BankingApplication.DataAccess.DbContext
{
    public class BankingDBContext : IdentityDbContext<ApplicationUser>
    {
        public BankingDBContext()
        {
        }
        public BankingDBContext(DbContextOptions<BankingDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AuthUserMapping> AuthUserMappings { get; set; }
        public virtual DbSet<MasterPayeeDetail> MasterPayeeDetails { get; set; }
        public virtual DbSet<MasterTransaction> MasterTransactions { get; set; }
        public virtual DbSet<UserAccountDetail> UserAccountDetails { get; set; }
        public virtual DbSet<UserLoginTrack> UserLoginTracks { get; set; }
        public virtual DbSet<UserPrimaryDetail> UserPrimaryDetails { get; set; }
        public virtual DbSet<UserServiceProperty> UserServiceProperties { get; set; }
        public virtual DbSet<UserPayeeMapping> UserPayeeMappings { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<MasterPayeeDetail>().Ignore(x => x.TransacationModeNames);
            builder.Entity<MasterTransaction>().Ignore(x => x.payees);
            builder.Entity<MasterTransaction>().Ignore(x => x.userAccounts);
            builder.Entity<MasterPayeeDetail>().Ignore(x => x.BankType);

            base.OnModelCreating(builder);
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);
        }
    }
}

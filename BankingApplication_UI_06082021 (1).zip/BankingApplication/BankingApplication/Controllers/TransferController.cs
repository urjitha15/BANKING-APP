﻿using BankingApplication.DataAccess.DTO;
using BankingApplication.DataAccess.Models;
using BankingApplication.Services;
using BankingApplication.Services.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BankingApplication.Controllers
{
    [Authorize(Roles = "Customer")]
    public class TransferController : Controller
    {
        private readonly IOperations _service;

        public TransferController(IOperations service)
        {
            _service = service;
        }

        // GET: Transfer
        public async Task<ActionResult> Index()
        {
            MasterTransaction objMasterTransaction = new MasterTransaction();
            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Name);
                objMasterTransaction = await _service.GetUserTransactionIndexDetailsAsync(userName);
                return View(objMasterTransaction);
            }
            catch (AccountException ex)
            {
                ModelState.AddModelError("NoAccounts", (ex.InnerException ?? ex).Message);
                objMasterTransaction.userAccounts = new List<UserAccountDetail>();
                objMasterTransaction.payees = new List<UserPayeeMapping>();
                return View(objMasterTransaction);
            }
            catch (PayeeException ex)
            {
                ModelState.AddModelError("NoPayees", (ex.InnerException ?? ex).Message);
                objMasterTransaction.userAccounts = new List<UserAccountDetail>();
                objMasterTransaction.payees = new List<UserPayeeMapping>();
                return View(objMasterTransaction);
            }
        }
        
        // POST: Transfer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Index(MasterTransaction transferDetails)
        {           
            var userName = User.FindFirstValue(ClaimTypes.Name);
            MasterTransaction objMasterTransaction;
            try
            {
                objMasterTransaction = await _service.InitiateTransfers(transferDetails);
                return RedirectToAction("Confirm", objMasterTransaction);
            }
            catch (AccountException ex)
            {
                ModelState.AddModelError("NoAccounts", (ex.InnerException ?? ex).Message);                
                objMasterTransaction = await _service.GetUserTransactionIndexDetailsAsync(userName);
                return View(objMasterTransaction);
            }
            catch (PayeeException ex)
            {
                ModelState.AddModelError("NoPayees", (ex.InnerException ?? ex).Message);                
                objMasterTransaction = await _service.GetUserTransactionIndexDetailsAsync(userName);
                return View(objMasterTransaction);
            }
            catch (InSufficientFund ex)
            {
                ModelState.AddModelError("InSufficientFund", (ex.InnerException ?? ex).Message);
                objMasterTransaction = await _service.GetUserTransactionIndexDetailsAsync(userName);
                return View(objMasterTransaction);
            }

        }

        public ActionResult Confirm(MasterTransaction transferDetails)
        {
            var confirmedDetails = _service.GetFundTransferConfirmationsAync(transferDetails);
            return View(confirmedDetails);
        }

        // POST: Transfer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ConfirmAsync(ConfirmTransfer transfer)
        {
            ErrorViewModel errorViewModel = await _service.ConfirmTransfers(transfer);
            return View("Error", errorViewModel);
        }

    }
}
﻿using BankingApplication.DataAccess.DbContext;
using BankingApplication.DataAccess.DTO;
using BankingApplication.DataAccess.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BankingApplication.Services
{
    public interface IOperations
    {
        Task<string> RegisterUserAsync(ApplicationUser userDetails);
        Task InsertLogInTrack(string userName, TransactionStatus status);
        Task<int> InsertPayeeDetails(string userName, MasterPayeeDetail payeeDetails);
        Task<MasterTransaction> InitiateTransfers(MasterTransaction transferDetails);
        Task<ErrorViewModel> ConfirmTransfers(ConfirmTransfer confirmation);
        Task<ConfirmTransfer> InitiateTransferByAdmin(string userName, ConfirmTransfer transfer);
        Task<ErrorViewModel> ConfirmTransfersByAdmin(ConfirmTransfer transfer);

        Task<MasterTransaction> GetUserTransactionIndexDetailsAsync(string userName);
        ConfirmTransfer GetFundTransferConfirmationsAync(MasterTransaction initiatedTransfer);
        Task<AccountActivity> GetAccountActivityAsync(string userName);
        Task<UserIndexInfo> GetUserDetailsAsync(string userName, string accountNumber = "");
        ErrorViewModel GetMessageModel(string _message, bool _type, string _requestId = "");
        Task<List<UserPayeeMapping>> GetUserPayeeDetailsAsync(string userName, int? Id = null, bool IsToTransfer = false);
        ConfirmTransfer GetFundTransferConfirmationsAdminAync(ConfirmTransfer initiatedTransfer);



        Task UpdatePayeeDetails(UserPayeeMapping payeeDetails);
        Task DeletePayeeDetails(int Id);
    }
}

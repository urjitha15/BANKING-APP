﻿namespace BankingApplication.DataAccess.Models
{
    public partial class UserPayeeMapping
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public int PayeeId { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }

        public virtual MasterPayeeDetail Payee { get; set; }
    }
}

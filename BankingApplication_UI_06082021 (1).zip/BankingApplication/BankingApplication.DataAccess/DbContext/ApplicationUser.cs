﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace BankingApplication.DataAccess.DbContext
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
        [StringLength(20, ErrorMessage = "20 Characters is Maximum legnth allowed")]
        public string FirstName { get; set; }

        [StringLength(20, ErrorMessage = "20 Characters is Maximum legnth allowed")]
        public string LastName { get; set; }

        [StringLength(500, ErrorMessage = "500 Characters is Maximum legnth allowed")]
        public string Address { get; set; }
    }
}
